let Valor1 = document.querySelector("#Valor1");
let Valor2 = document.querySelector("#Valor2");
let Valor3 = document.querySelector("#Valor3");
let Valor4 = document.querySelector("#Valor4");
let btMaior = document.querySelector("#btMenor");
let Resultado = document.querySelector("#Resultado");

function Menor() {
    let num1 = Number(Valor1.value);
    let num2 = Number(Valor2.value);
    let num3 = Number(Valor2.value);
    let num4 = Number(Valor2.value);

    
    if (num1 > num2 < num3 < num4) {
        Resultado.textContent = `${num1}`;
    } else if (num2 > num1 < num3 < num4) {
        Resultado.textContent = `${num2}`;
    } else if (num3 > num1 < num2 < num4) {
        Resultado.textContent = `${num3}`;
    } else if (num4 > num1 < num2 < num3) {
        Resultado.textContent = `${num4}`;
    } else {
        Resultado.textContent = "Os quatro valores são iguais.";
    }
}

btMenor.onclick = function() {
    Menor();
}